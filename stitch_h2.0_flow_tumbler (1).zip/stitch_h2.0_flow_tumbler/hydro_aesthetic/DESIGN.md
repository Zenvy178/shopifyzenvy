---
name: Hydro-Aesthetic
colors:
  surface: '#fbf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#414848'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0f0'
  outline: '#727879'
  outline-variant: '#c1c8c8'
  surface-tint: '#486365'
  primary: '#476163'
  on-primary: '#ffffff'
  primary-container: '#5f7a7c'
  on-primary-container: '#f8ffff'
  inverse-primary: '#afccce'
  secondary: '#5c5f60'
  on-secondary: '#ffffff'
  secondary-container: '#e1e3e4'
  on-secondary-container: '#626566'
  tertiary: '#5b5c5d'
  on-tertiary: '#ffffff'
  tertiary-container: '#747575'
  on-tertiary-container: '#fefdfd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cbe8ea'
  primary-fixed-dim: '#afccce'
  on-primary-fixed: '#031f21'
  on-primary-fixed-variant: '#314b4d'
  secondary-fixed: '#e1e3e4'
  secondary-fixed-dim: '#c5c7c8'
  on-secondary-fixed: '#191c1d'
  on-secondary-fixed-variant: '#454748'
  tertiary-fixed: '#e3e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e1'
typography:
  headline-xl:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.8'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  container-max: 1280px
---

## Brand & Style
The design system focuses on a premium lifestyle experience, blending the purity of natural elements with the precision of modern engineering. The target audience is the health-conscious urban professional who values "quiet luxury" and sustainable aesthetics.

The design style is **Corporate / Modern** with a strong influence of **Minimalism**. It prioritizes a high-quality product photography focus, using generous whitespace to create an atmosphere of calm and clarity. The UI should evoke a sense of refreshment and reliability, utilizing subtle depth and high-end finishes to mirror the physical quality of premium stainless steel hydration products.

## Colors
The palette is rooted in a sophisticated Sage Green (`#5F7A7C`) that represents both water and natural wellness. This is supported by a foundation of Crisp Whites (`#F8F9FA`) and Light Grays to maintain an "ultra-aesthetic," airy feel.

Metallic Silver (`#C0C0C0`) is used as a technical accent to reference premium materials like brushed aluminum and stainless steel. Charcoal (`#333333`) provides the necessary contrast for high-legibility typography and grounding elements. All colors should be applied with high luminosity to ensure the interface feels breathable.

## Typography
Typography is architectural and clean. **Montserrat** is used for headlines to convey a bold, modern, and trustworthy presence. **Inter** handles all body copy and UI labels, selected for its exceptional legibility and neutral, systematic feel.

A key characteristic of this design system is **generous line-height** (1.6 to 1.8) for body text, which enhances the feeling of whitespace and premium editorial design. Headlines utilize slightly tighter tracking to maintain a strong, punchy visual impact against the open layout.

## Layout & Spacing
The design system employs a **fixed grid** model for desktop to ensure product photography is framed perfectly, and a **fluid grid** for mobile to maximize utility. 

- **Desktop:** 12-column grid with a 1280px max-width container. Margins are intentionally wide (64px) to emphasize the premium nature of the brand.
- **Mobile:** 4-column fluid grid with 20px margins.
- **Rhythm:** An 8px linear scale governs all spacing. Vertical rhythm should be intentionally loose; use larger spacers (64px, 80px, 128px) between major sections to let the content breathe.

## Elevation & Depth
Visual hierarchy is established through **ambient shadows** and **tonal layering**. Shadows should be extra-diffused, using a very low opacity (5-8%) with a slight tint of the primary sage color to avoid "dirty" gray shadows.

- **Level 1 (Cards/Inputs):** Subtle 4px blur, 2px Y-offset. Used for interactive elements.
- **Level 2 (Dropdowns/Modals):** 16px blur, 8px Y-offset. Used for elements that temporarily float above the UI.
- **Glassmorphism:** Use backdrop blurs (20px) on navigation bars and overlays to maintain a sense of depth and "water-like" transparency without cluttering the view.

## Shapes
The shape language is defined by a **Rounded** (0.5rem / 8px) aesthetic. This corner radius strikes a balance between professional precision and approachable softness. 

Larger containers and product cards should utilize `rounded-lg` (16px) or `rounded-xl` (24px) to create a soft, high-end feel that mimics the ergonomic curves of the hydration vessels themselves. Form inputs and buttons stay consistently at 8px to maintain a crisp, functional appearance.

## Components

- **Buttons:** Primary buttons use a solid Sage Green fill with white Montserrat text. Secondary buttons use a Silver metallic border with Charcoal text. Padding should be generous (16px 32px).
- **Inputs:** Fields use a light gray background (`#F8F9FA`) with a subtle 1px border. On focus, the border transitions to Sage Green with a soft outer glow.
- **Cards:** Product cards are borderless with a soft Level 1 shadow. They rely on high-resolution photography that bleeds to the top and sides of the card.
- **Chips/Badges:** Used for product features (e.g., "BPA Free," "24h Cold"). These should be pill-shaped with a light Sage tint and dark Sage text.
- **Progress Indicators:** Used for hydration tracking or checkout steps. Use thin, 2px lines with soft rounded caps.
- **Hero Sections:** Large-scale imagery combined with `headline-xl` typography. Text should never overlap busy parts of an image; use whitespace or subtle gradients if necessary.